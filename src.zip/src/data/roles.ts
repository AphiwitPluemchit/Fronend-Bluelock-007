export enum EnumUserRole {
  ADMIN = 'Admin',
  STUDENT = 'Student',
}
