export type Major = {
  id: string
  name: string
}
