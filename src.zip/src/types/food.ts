export type Food = {
  id?: string
  name: string
}

export type FoodVote = {
  vote: number
  foodName: string
}
